package �÷���;

import java.util.ArrayList;

public class �����ִ¸�� {

	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		list.add("ȫ�浿");
		list.add(100);
		list.add(11.22);
		list.add(true);
		System.out.println(list);
	}
}




