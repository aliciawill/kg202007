package ���;

public class ManagerUser {

	public static void main(String[] args) {
		Manager m = new Manager();
		m.name = "ȫ�Ŵ���";
		m.address = "������";
		m.salary =100;
		m.rrn = 880101;
		m.bonus = 50;
		System.out.println(m);
		m.test();
	}

}
