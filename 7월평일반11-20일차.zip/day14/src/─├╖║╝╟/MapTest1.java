package �÷���;

import java.util.HashMap;

public class MapTest1 {

	public static void main(String[] args) {
		HashMap dic = new HashMap();
		dic.put("apple", "���");
		dic.put("banana", "�ٳ���");
		dic.put("melon", "�޷�");
		System.out.println(dic);
		System.out.println(dic.get("apple"));
	}

}




