package Ŭ���������;

public class ��ǰ {
	int no;
	String name;
	int price;
	String company;
	
	public void print() {
		System.out.println(no + ", " + 
						   name + ", " + 
						   price + ", " + 
						   company);
	}
}



