package ��ӻ�����;

public class CoffeeUser {

	public static void main(String[] args) {
		CoffeeTruck coffee = new CoffeeTruck(300, 1, 5000);
		
		System.out.println(coffee);
	}

}
