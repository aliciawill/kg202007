package ��ӻ�����;

public class SuperManUser {

	public static void main(String[] args) {
		SuperMan sMan = new SuperMan(100, 100);
		System.out.println(sMan);
	}

}
